Hello from the HyLauncher team!

Thank you for testing our launcher. This is our biggest update!

We've implemented QoL improvements in the internal code 
Added the option to change the installation folder 
Added a fix to change avatar and play on servers online 
And added a safe uninstall button that keeps all your worlds, mods, etc. saved

Join our Discord server for future updates! Link on our website.

HyLauncher.net Team.