This launcher doesn't download Hytale.
you need the original game or the game.zip file, which might be on Discord.

The game.zip file must be in this same folder to be considered an installation file.

HyLauncher.net Team.