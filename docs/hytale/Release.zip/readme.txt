Hello from the HyLauncher team!

Thank you for testing our launcher. In this update,
we've implemented direct online install within the launcher, with an update checker!

If you don't have internet access, you can use the old game.zip file to install!
The game.zip file must be in this same folder to be considered an installation file.

Join our Discord server for future updates! Link on our website.

HyLauncher.net Team.