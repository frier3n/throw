Hello from the HyLauncher team!

Thank you for testing our launcher.

In this update, we've added several options to the
launcher settings (top right) that will make using the launcher easier.

And now you can choose the pre-release version to install and play.

If you experience errors, open the launcher settings and click Repair.

Join our Discord server for future updates! Link on our website.

HyLauncher.net Team.