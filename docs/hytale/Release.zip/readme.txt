Hello from the HyLauncher team!

Thank you for testing our launcher. This is a fix update.

We fixed the fix of the OnlineFix, and now it's automatically applied when you install the game.
For existing users who didn't have the patch applied, the button is still available.

Join our Discord server for future updates! Link on our website.

HyLauncher.net Team.